# P&A Consult — Portfolio Website

A modern, responsive one-page portfolio site built with HTML, CSS and vanilla JavaScript.

## Included
- Responsive desktop, tablet and mobile layouts
- Mobile navigation with accessible expanded state
- Approach, services, about and contact sections
- Contact form with required-field and email validation
- GitHub Actions workflow for GitHub Pages
- Basic automated static checks using Node's built-in test runner

## Run locally
Open `index.html` in a browser, or run a local server:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000.

## Configure the contact form
In `script.js`, replace `hello@example.com` with the real P&A Consult inbox. The form uses a `mailto:` link to open the visitor's email application with a pre-filled message. It does not send or store submissions on a server. For an embedded form submission, connect a form provider or backend before launch.

## Personalise before launch
The service and About copy is starter content. Update it to accurately describe P&A Consult's work, add the correct business contact details, and review any privacy/legal information needed for your business.

## Test
Requires Node.js 18 or newer:

```bash
npm test
```

These are static project checks, not full cross-browser end-to-end tests. Also preview the site on a phone and desktop before publishing.

## Create a new GitHub repository and publish
1. Sign in to GitHub and choose **New repository**.
2. Name it `pa-consult-portfolio` (or another name you prefer). Choose Public or Private, and create it without adding a README/license (this project already includes a README).
3. Extract this project ZIP on your computer.
4. In the new repository, choose **Add file → Upload files** and upload the *contents* of the extracted folder (including the hidden `.github` folder), then commit to the `main` branch.
5. In the repository, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
6. Open the **Actions** tab and confirm the “Deploy static site to GitHub Pages” workflow completes successfully.
7. Your live URL will be shown under **Settings → Pages**.

The included `.github/workflows/deploy.yml` runs the checks and deploys the static site whenever you push to `main`.
