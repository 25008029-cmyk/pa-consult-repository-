// Replace with P&A Consult's real enquiries inbox before publishing.
const CONTACT_EMAIL = "hello@example.com";

const menuButton = document.querySelector(".menu");
const navLinks = document.querySelector("#links");
if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  });
  navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
  }));
}
const year = document.querySelector("#year");
if (year) year.textContent = String(new Date().getFullYear());

const form = document.querySelector("#contact-form");
if (form) form.addEventListener("submit", event => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const status = document.querySelector("#form-status");
  if (CONTACT_EMAIL === "hello@example.com") {
    status.textContent = "Form validation passed. Add your real recipient email in script.js to enable the email handoff.";
    return;
  }
  const data = new FormData(form);
  const subject = encodeURIComponent(`Website enquiry from ${data.get("name")}`);
  const body = encodeURIComponent(`Name: ${data.get("name")}\nEmail: ${data.get("email")}\n\n${data.get("message")}`);
  window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
});
