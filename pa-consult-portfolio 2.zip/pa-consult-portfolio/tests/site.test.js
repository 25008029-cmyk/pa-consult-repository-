const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.join(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const css = fs.readFileSync(path.join(root, "styles.css"), "utf8");
const js = fs.readFileSync(path.join(root, "script.js"), "utf8");

test("portfolio page contains all main sections", () => {
  for (const id of ["home", "approach", "services", "about", "contact"])
    assert.ok(html.includes(`id="${id}"`), `missing section ${id}`);
});
test("contact form includes required fields and native validation", () => {
  assert.match(html, /id="contact-form"/);
  assert.match(html, /name="name"[^>]*required/);
  assert.match(html, /name="email"[^>]*type="email"[^>]*required/);
  assert.match(html, /name="message"[^>]*required/);
});
test("responsive and reduced-motion styles are present", () => {
  assert.match(css, /max-width:\s*800px/);
  assert.match(css, /max-width:\s*600px/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});
test("navigation and contact form scripts are wired", () => {
  assert.match(js, /menuButton\.addEventListener\("click"/);
  assert.match(js, /form\.addEventListener\("submit"/);
  assert.match(js, /reportValidity\(\)/);
});
